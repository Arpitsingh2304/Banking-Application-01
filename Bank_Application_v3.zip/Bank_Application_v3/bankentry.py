from account_creation import create_account
from account_management import display_account_details, deposit_money, withdraw_money, login


def main():
    customers = []
    used_emails = set()
    used_phone_numbers = set()

    while True:
        print("\nOptions:")
        print("1. Create New Account")
        print("2. Log In")
        print("3. Exit")

        choice = input("Enter your choice (1-3): ")

        if choice == "1":
            customer = create_account(customers, used_emails, used_phone_numbers)
            display_account_details(customer)
        elif choice == "2":
            email = input("Enter your email address: ")
            password = input("Enter your password: ")
            logged_in_customer = login(email, password, customers)
            if logged_in_customer:
                display_account_details(logged_in_customer)
                action = input("Do you want to deposit money (A) or withdraw money (W)? ").upper()
                if action == "A":
                    deposit_money(logged_in_customer)
                elif action == "W":
                    withdraw_money(logged_in_customer)
        elif choice == "3":
            print("Exit, Thank you!")
            break
        else:
            print("Invalid choice. Please enter a number between 1 and 3.")


if __name__ == "__main__":
    main()
