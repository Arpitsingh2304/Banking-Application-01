from typing import Union

from customer import Customer


def display_account_details(customer: Customer) -> None:
    print("\nAccount Details:")
    print(f"Name: {customer.name}")
    print(f"Address: {customer.address}")
    print(f"Mobile Number: {customer.mobile_number}")
    print(f"Balance: {customer.balance}")
    print(f"Email: {customer.email}")
    print(f"Account Number: {customer.account_number}")
    print(f"Password: {customer.password}")


def withdraw_money(customer: Customer) -> None:
    amount = float(input("Enter the amount to withdraw: "))
    if customer.balance - amount >= 1000:
        customer.balance -= amount
        print(f"Withdrawal successful. Current balance: {customer.balance}")
    else:
        print("Withdrawal denied. Insufficient funds.")


def deposit_money(customer: Customer) -> None:
    amount = float(input("Enter the amount to deposit: "))
    customer.balance += amount
    print(f"Money deposited successfully. Current balance: {customer.balance}")


def login(email: str, password: str, customers: list) -> Union[Customer, None]:
    for customer in customers:
        if customer.email == email and customer.password == password:
            return customer
    print("Invalid email or password.")
    return None
