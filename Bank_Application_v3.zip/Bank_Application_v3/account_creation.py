from customer import Customer
import random
import string


def generate_account_number(customers: list) -> str:
    return str(len(customers) + 1).zfill(6)


def generate_random_password() -> str:
    password_characters = string.ascii_letters + string.digits
    return ''.join(random.choice(password_characters) for i in range(8))


def create_account(customers: list, used_emails: set, used_phone_numbers: set) -> Customer:
    print("Creating a new account...")
    name = input("Enter your name: ")
    address = input("Enter your address: ")

    while True:
        try:
            initial_amount = float(input("Enter initial amount (minimum 1000): "))
            if initial_amount >= 1000:
                break
            else:
                print("Initial amount must be at least 1000.")
        except ValueError:
            print("Invalid input. Please enter a valid number.")

    while True:
        mobile_number = input("Enter your 10-digit mobile number: ")
        if mobile_number.isdigit() and len(mobile_number) == 10:
            if mobile_number not in used_phone_numbers:
                break
            else:
                print("Mobile number already in use. Please enter a different mobile number.")
        else:
            print("Invalid mobile number. Please enter a 10-digit number.")

    while True:
        email = input("Enter your email address: ")
        if email not in used_emails:
            used_emails.add(email)
            break
        else:
            print("This email is already in use. Please choose a different email.")

    password = generate_random_password()
    account_number = generate_account_number(customers)

    customer = Customer(name, address, mobile_number, initial_amount, email, password, account_number)

    customers.append(customer)

    print(f"Account created successfully! Your account number is: {account_number}")
    print(f"Your randomly generated password is: {password}")
    print("Please remember your email and password for future logins.")
    return customer
