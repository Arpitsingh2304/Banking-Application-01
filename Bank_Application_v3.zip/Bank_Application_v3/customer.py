class Customer:
    def __init__(self, name: str, address: str, mobile_number: str, balance: float, email: str, password: str, account_number: str) -> None:
        self.name: str = name
        self.address: str = address
        self.mobile_number: str = mobile_number
        self.balance: float = balance
        self.email: str = email
        self.password: str = password
        self.account_number: str = account_number

    def display_account_details(self):
        pass

